package com.library.app.model;

import java.util.Date;

/**
 * Model class that represents a borrowing/returning transaction.
 */
public class Transaction {
    private int id;
    private int bookId;
    private int memberId;
    private Date borrowDate;
    private Date dueDate;
    private Date returnDate;
    private String status; // BORROWED, RETURNED, OVERDUE, LOST, RENEWED
    private double fine;
    private String remarks;
    
    // Denormalized fields for display
    private String bookTitle;
    private String memberName;
    
    /**
     * Default constructor.
     */
    public Transaction() {
        this.borrowDate = new Date();
        this.status = "BORROWED";
        this.fine = 0.0;
    }
    
    /**
     * Parameterized constructor with essential fields.
     * 
     * @param bookId The ID of the borrowed book
     * @param memberId The ID of the borrowing member
     * @param borrowDate The date of borrowing
     * @param dueDate The due date for return
     */
    public Transaction(int bookId, int memberId, Date borrowDate, Date dueDate) {
        this.bookId = bookId;
        this.memberId = memberId;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.status = "BORROWED";
        this.fine = 0.0;
    }
    
    /**
     * Complete constructor with all fields.
     * 
     * @param id The ID of the transaction
     * @param bookId The ID of the borrowed book
     * @param memberId The ID of the borrowing member
     * @param borrowDate The date of borrowing
     * @param dueDate The due date for return
     * @param returnDate The actual return date
     * @param status The status of the transaction
     * @param fine The fine amount if any
     * @param remarks Any additional remarks
     * @param bookTitle The title of the book (denormalized)
     * @param memberName The name of the member (denormalized)
     */
    public Transaction(int id, int bookId, int memberId, Date borrowDate, Date dueDate, 
                      Date returnDate, String status, double fine, String remarks, 
                      String bookTitle, String memberName) {
        this.id = id;
        this.bookId = bookId;
        this.memberId = memberId;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.status = status;
        this.fine = fine;
        this.remarks = remarks;
        this.bookTitle = bookTitle;
        this.memberName = memberName;
    }

    // Getters and Setters
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public Date getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(Date borrowDate) {
        this.borrowDate = borrowDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getFine() {
        return fine;
    }

    public void setFine(double fine) {
        this.fine = fine;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    @Override
    public String toString() {
        return "Transaction{" +
               "id=" + id +
               ", bookId=" + bookId +
               ", memberId=" + memberId +
               ", borrowDate=" + borrowDate +
               ", dueDate=" + dueDate +
               ", status='" + status + '\'' +
               '}';
    }

    /**
     * Check if the transaction is overdue.
     * 
     * @return true if the transaction is overdue, false otherwise
     */
    public boolean isOverdue() {
        if ("RETURNED".equals(status)) {
            return false;
        }
        Date currentDate = new Date();
        return currentDate.after(dueDate);
    }
    
    /**
     * Calculate the number of days overdue.
     * 
     * @return The number of days overdue (0 if not overdue)
     */
    public long getDaysOverdue() {
        if (!isOverdue()) {
            return 0;
        }
        
        Date currentDate = new Date();
        long diffInMillis = currentDate.getTime() - dueDate.getTime();
        return diffInMillis / (24 * 60 * 60 * 1000);
    }
    
    /**
     * Calculate the fine amount for overdue days.
     * 
     * @param finePerDay The fine amount per day
     * @return The calculated fine amount
     */
    public double calculateFine(double finePerDay) {
        long daysOverdue = getDaysOverdue();
        return daysOverdue * finePerDay;
    }
    
    /**
     * Renew the transaction with a new due date.
     * 
     * @param renewalDays The number of days to extend
     * @return true if renewal was successful, false otherwise
     */
    public boolean renew(int renewalDays) {
        if ("BORROWED".equals(status) && !isOverdue()) {
            long dueTime = dueDate.getTime();
            dueDate = new Date(dueTime + (renewalDays * 24 * 60 * 60 * 1000));
            remarks = (remarks != null ? remarks + "; " : "") + "Renewed for " + renewalDays + " days";
            return true;
        }
        return false;
    }
}
