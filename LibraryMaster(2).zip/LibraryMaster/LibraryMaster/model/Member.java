package com.library.app.model;

import java.util.Date;
import java.util.Objects;

/**
 * Model class that represents a library member.
 */
public class Member {
    private int id;
    private String name;
    private String email;
    private String phone;
    private String address;
    private Date joinDate;
    private Date expiryDate;
    private String role; // REGULAR, PREMIUM, ADMIN
    private String status; // ACTIVE, INACTIVE, SUSPENDED
    private String password;
    private int borrowedCount;
    private double fineAmount;
    private String profileImage;
    
    /**
     * Default constructor.
     */
    public Member() {
        this.joinDate = new Date();
        this.role = "REGULAR";
        this.status = "ACTIVE";
        this.borrowedCount = 0;
        this.fineAmount = 0.0;
    }
    
    /**
     * Parameterized constructor with essential fields.
     * 
     * @param name The name of the member
     * @param email The email of the member
     * @param phone The phone number of the member
     */
    public Member(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.joinDate = new Date();
        this.role = "REGULAR";
        this.status = "ACTIVE";
        this.borrowedCount = 0;
        this.fineAmount = 0.0;
    }
    
    /**
     * Complete constructor with all fields.
     * 
     * @param id The ID of the member
     * @param name The name of the member
     * @param email The email of the member
     * @param phone The phone number of the member
     * @param address The address of the member
     * @param joinDate The date the member joined
     * @param expiryDate The date the membership expires
     * @param role The role of the member
     * @param status The status of the member
     * @param password The member's password
     * @param borrowedCount The number of books borrowed
     * @param fineAmount The amount of fines owed
     * @param profileImage The path or URL to the profile image
     */
    public Member(int id, String name, String email, String phone, String address, 
                 Date joinDate, Date expiryDate, String role, String status, 
                 String password, int borrowedCount, double fineAmount, String profileImage) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.joinDate = joinDate;
        this.expiryDate = expiryDate;
        this.role = role;
        this.status = status;
        this.password = password;
        this.borrowedCount = borrowedCount;
        this.fineAmount = fineAmount;
        this.profileImage = profileImage;
    }

    // Getters and Setters
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(Date joinDate) {
        this.joinDate = joinDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getBorrowedCount() {
        return borrowedCount;
    }

    public void setBorrowedCount(int borrowedCount) {
        this.borrowedCount = borrowedCount;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Member member = (Member) o;
        return id == member.id ||
               (email != null && email.equals(member.email));
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, email);
    }

    @Override
    public String toString() {
        return "Member{" +
               "id=" + id +
               ", name='" + name + '\'' +
               ", email='" + email + '\'' +
               ", role='" + role + '\'' +
               ", status='" + status + '\'' +
               ", borrowedCount=" + borrowedCount +
               '}';
    }

    /**
     * Creates a copy of this member with the same values.
     * 
     * @return A new Member object with the same values
     */
    public Member copy() {
        Member copy = new Member();
        copy.id = this.id;
        copy.name = this.name;
        copy.email = this.email;
        copy.phone = this.phone;
        copy.address = this.address;
        copy.joinDate = this.joinDate != null ? new Date(this.joinDate.getTime()) : null;
        copy.expiryDate = this.expiryDate != null ? new Date(this.expiryDate.getTime()) : null;
        copy.role = this.role;
        copy.status = this.status;
        copy.password = this.password;
        copy.borrowedCount = this.borrowedCount;
        copy.fineAmount = this.fineAmount;
        copy.profileImage = this.profileImage;
        return copy;
    }

    /**
     * Checks if the membership is expired.
     * 
     * @return true if the membership is expired, false otherwise
     */
    public boolean isExpired() {
        if (expiryDate == null) {
            return false;
        }
        return new Date().after(expiryDate);
    }

    /**
     * Gets the maximum allowed borrows based on member role.
     * 
     * @return The maximum number of books the member can borrow
     */
    public int getMaxAllowedBorrows() {
        if ("PREMIUM".equalsIgnoreCase(role)) {
            return 10;
        } else if ("ADMIN".equalsIgnoreCase(role)) {
            return 15;
        } else {
            return 5; // REGULAR members
        }
    }

    /**
     * Checks if the member can borrow more books.
     * 
     * @return true if the member can borrow more books, false otherwise
     */
    public boolean canBorrowMore() {
        return borrowedCount < getMaxAllowedBorrows() && 
               "ACTIVE".equalsIgnoreCase(status) && 
               !isExpired();
    }
}
