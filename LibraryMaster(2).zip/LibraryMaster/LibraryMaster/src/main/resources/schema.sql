-- Create Books table
CREATE TABLE IF NOT EXISTS books (
    id SERIAL PRIMARY KEY,
    isbn VARCHAR(20) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    publisher VARCHAR(255),
    publication_year INT,
    genre VARCHAR(100),
    description TEXT,
    status VARCHAR(20) DEFAULT 'AVAILABLE',
    location VARCHAR(100),
    total_copies INT DEFAULT 1,
    available_copies INT DEFAULT 1,
    cover_image VARCHAR(255),
    language VARCHAR(50),
    page_count INT,
    price DECIMAL(10, 2)
);

-- Create Members table
CREATE TABLE IF NOT EXISTS members (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date TIMESTAMP,
    membership_type VARCHAR(50) DEFAULT 'REGULAR',
    status VARCHAR(20) DEFAULT 'ACTIVE',
    max_books INT DEFAULT 5,
    role VARCHAR(20) DEFAULT 'MEMBER',
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255)
);

-- Create Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    book_id INT NOT NULL,
    member_id INT NOT NULL,
    borrow_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    due_date TIMESTAMP NOT NULL,
    return_date TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- We've removed the fines system from the application
-- Keeping this comment as a placeholder for database compatibility reasons

-- Create Reservations table
CREATE TABLE IF NOT EXISTS reservations (
    id SERIAL PRIMARY KEY,
    book_id INT NOT NULL,
    member_id INT NOT NULL,
    reservation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date TIMESTAMP NOT NULL,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Create Events table (for tracking system events)
CREATE TABLE IF NOT EXISTS events (
    id SERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    description TEXT,
    entity_type VARCHAR(50),
    entity_id INT,
    user_id INT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    details TEXT
);

-- Create Settings table (for system configuration)
CREATE TABLE IF NOT EXISTS settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default settings
INSERT INTO settings (setting_key, setting_value, description) 
VALUES
('loan_period_days', '14', 'Default loan period in days'),
('max_renewals', '2', 'Maximum number of renewals allowed'),
('reservation_period_days', '3', 'Days a reservation is held'),
('library_name', 'Community Library', 'Name of the library')
ON CONFLICT (setting_key) DO UPDATE SET updated_at = CURRENT_TIMESTAMP;

-- Insert sample data for testing
INSERT INTO books (isbn, title, author, publisher, publication_year, genre, description, status) 
VALUES 
('9780451524935', 'Nineteen Eighty-Four', 'George Orwell', 'Signet Classics', 1949, 'Fiction', 'A dystopian novel about totalitarianism.', 'AVAILABLE'),
('9780061120084', 'To Kill a Mockingbird', 'Harper Lee', 'Harper Perennial', 1960, 'Fiction', 'A novel about racial injustice and moral growth.', 'AVAILABLE'),
('9780743273565', 'The Great Gatsby', 'F. Scott Fitzgerald', 'Scribner', 1925, 'Fiction', 'A novel about the American Dream and its corruption.', 'AVAILABLE'),
('9780142437230', 'Pride and Prejudice', 'Jane Austen', 'Penguin Classics', 1813, 'Romance', 'A novel of manners about marriage and social status.', 'AVAILABLE'),
('9780553211404', 'Moby Dick', 'Herman Melville', 'Bantam Classics', 1851, 'Adventure', 'A novel about obsession and revenge at sea.', 'AVAILABLE'),
('9780547928227', 'The Hobbit', 'J.R.R. Tolkien', 'Mariner Books', 1937, 'Fantasy', 'A fantasy novel about a hobbit who goes on an adventure.', 'AVAILABLE'),
('9780345538376', 'The Martian', 'Andy Weir', 'Crown Publishing', 2011, 'Science Fiction', 'A novel about an astronaut stranded on Mars.', 'AVAILABLE'),
('9780307743657', 'The Shining', 'Stephen King', 'Anchor', 1977, 'Horror', 'A horror novel about a family isolated in a haunted hotel.', 'AVAILABLE'),
('9780060935467', 'To Kill a Mockingbird 2', 'Harper Lee', 'Harper Perennial', 1960, 'Fiction', 'A novel about racial injustice and moral growth.', 'AVAILABLE'),
('9780439064866', 'Harry Potter and the Chamber of Secrets', 'J.K. Rowling', 'Scholastic', 1998, 'Fantasy', 'The second book in the Harry Potter series.', 'AVAILABLE')
ON CONFLICT (isbn) DO UPDATE SET title = EXCLUDED.title;

-- Insert sample members
INSERT INTO members (name, email, phone, address, membership_type, role, username, password) 
VALUES 
('John Smith', 'john.smith@example.com', '555-123-4567', '123 Main St, Anytown, USA', 'REGULAR', 'MEMBER', 'johnsmith', 'password123'),
('Jane Doe', 'jane.doe@example.com', '555-987-6543', '456 Oak Ave, Somewhere, USA', 'PREMIUM', 'MEMBER', 'janedoe', 'password123'),
('Admin User', 'admin@library.com', '000-000-0000', 'Library Address', 'STAFF', 'ADMIN', 'admin', 'admin123')
ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name;